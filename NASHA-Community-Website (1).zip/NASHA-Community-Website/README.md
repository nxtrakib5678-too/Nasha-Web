# NASHA Community Team Website

## Publish with GitHub Pages
1. Upload `index.html` to the root of your GitHub repository.
2. Open **Settings → Pages**.
3. Choose **Deploy from a branch**, select `main` and `/(root)`, then Save.

## Before publishing
Open `index.html` and change:
- `ADMIN_PASSWORD` from the demo value `nasha123`
- `DISCORD_INVITE` to your real Discord invite URL

This starter stores team edits in the current browser only. For a shared admin panel with secure login and data shared across visitors, connect Supabase or Firebase. The demo password is visible in frontend source and is not secure authentication.
